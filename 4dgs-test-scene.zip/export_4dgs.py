import bpy
import os
import math
import shutil
import struct
import mathutils
import numpy as np
from mathutils import Matrix

# --- CONFIGURATION ---
NUM_CAMERAS = 42                    # Total number of stationary cameras
DOME_RADIUS = 150                   # Distance from the cameras to the object
END_FRAME = 20                      # Your animation length
# --- extra options ---------------------------------
START_FRAME = 1
POINTS_PER_FRAME = 100_000          # 3D points per frame (init for the trainer)
INIT_POINTS_BIN = 20_000            # points of frame 1 in points3D.bin
EXCLUDE_NAMES = []                  # e.g. ["Ground"] to exclude objects
TRANSPARENT_BACKGROUND = True       # True = RGBA renders (then train with --alpha-mode transparent --random-bkgd)
RENDER = True                       # False = everything except rendering (fast test)
TRAINER_IMG_FMT = "cam{cam:02d}/{frame:06d}.png"     # trainer_data/images/cam01/000000.png (one folder per camera)
COLMAP_NAME_FMT = "cam{cam:02d}.png"                 # name in images.bin ("flat" format)
# --------------------------------------------------

if not bpy.data.is_saved:
    raise Exception("Please SAVE your .blend file first so the script knows where to render!")

scene = bpy.context.scene
render = scene.render

BLEND_DIR = os.path.dirname(bpy.data.filepath)
OUTPUT_DIR = os.path.join(BLEND_DIR, "4DGS_Dataset")
TRAINER_DIR = os.path.join(OUTPUT_DIR, "trainer_data")
IMG_DIR = os.path.join(TRAINER_DIR, "images")
SPARSE_DIR = os.path.join(TRAINER_DIR, "sparse", "0")
POINTS_DIR = os.path.join(TRAINER_DIR, "points")
for d in (OUTPUT_DIR, IMG_DIR, SPARSE_DIR, POINTS_DIR):
    os.makedirs(d, exist_ok=True)

# Render settings we need (rest of your scene remains untouched)
render.image_settings.file_format = 'PNG'
render.image_settings.color_depth = '8'
if TRANSPARENT_BACKGROUND:
    render.film_transparent = True
    render.image_settings.color_mode = 'RGBA'

W = int(render.resolution_x * render.resolution_percentage / 100)
H = int(render.resolution_y * render.resolution_percentage / 100)
assert abs(render.pixel_aspect_x - render.pixel_aspect_y) < 1e-6, "Pixel aspect must be 1:1"

# Clean up any old cameras from a previous script run
for obj in list(bpy.data.objects):
    if obj.name.startswith("4DGS_Cam_"):
        bpy.data.objects.remove(obj, do_unlink=True)
for cam in list(bpy.data.cameras):
    if cam.name.startswith("4DGS_CamData_"):
        bpy.data.cameras.remove(cam, do_unlink=True)

# 1. Mathematically generate a perfect dome of cameras looking at the target center
cameras = []
target_center = mathutils.Vector((0.0, 0.0, 0.0))
phi = math.pi * (math.sqrt(5.0) - 1.0)  # golden angle in radians

for i in range(NUM_CAMERAS):
    y = 1.0 - (i / float(NUM_CAMERAS - 1)) if NUM_CAMERAS > 1 else 1.0
    radius_at_y = math.sqrt(max(0.0, 1.0 - y * y))
    theta = phi * i
    x = math.cos(theta) * radius_at_y
    z = math.sin(theta) * radius_at_y  # Blender uses Z as up

    cam_loc = mathutils.Vector((x * DOME_RADIUS, z * DOME_RADIUS, y * DOME_RADIUS)) + target_center

    cam_data = bpy.data.cameras.new(name=f"4DGS_CamData_{i}")
    cam_data.clip_start = 0.1
    cam_data.clip_end = max(1000.0, DOME_RADIUS * 4.0)   # FIX: default 100 clipped everything at 150
    cam_obj = bpy.data.objects.new(name=f"4DGS_Cam_{i:03d}", object_data=cam_data)
    bpy.context.collection.objects.link(cam_obj)

    cam_obj.location = cam_loc
    cam_obj.rotation_mode = 'QUATERNION'
    direction = target_center - cam_loc
    cam_obj.rotation_quaternion = direction.to_track_quat('-Z', 'Y')
    cameras.append(cam_obj)

# FIX 1: without this, matrix_world of new objects is still the identity
bpy.context.view_layer.update()
print(f"-> Automatically generated {len(cameras)} cameras tracking the world center!")


def focal_px(cd):
    """Focal length in pixels (pixels are square -> fx == fy)."""
    if cd.sensor_fit == 'VERTICAL':
        return H * cd.lens / cd.sensor_height
    if cd.sensor_fit == 'HORIZONTAL':
        return W * cd.lens / cd.sensor_width
    return max(W, H) * cd.lens / cd.sensor_width   # AUTO


fx = fy = focal_px(cameras[0].data)                 # FIX 3/4: real value, fy = fx
cx, cy = W / 2.0, H / 2.0
print(f"Resolution {W}x{H}, focal length {fx:.2f} px")

# FIX 2: Blender camera (-Z forward, Y up) -> COLMAP camera (+Z forward, Y down)
FLIP = Matrix.Diagonal((1.0, -1.0, -1.0, 1.0))
poses = []   # (qw,qx,qy,qz,tx,ty,tz) per camera, world-to-camera
for i, cam in enumerate(cameras):
    c2w = cam.matrix_world @ FLIP
    w2c = c2w.inverted()
    q = w2c.to_3x3().to_quaternion()
    t = w2c.to_translation()
    fwd = (c2w.to_3x3() @ mathutils.Vector((0, 0, 1))).normalized()
    assert fwd.dot((target_center - cam.location).normalized()) > 0.999, f"camera {i} is not looking at the center"
    poses.append((q.w, q.x, q.y, q.z, t.x, t.y, t.z))

# 2. COLMAP TXT in the root (IDs start at 1)
with open(os.path.join(OUTPUT_DIR, "cameras.txt"), "w") as f_cam, \
        open(os.path.join(OUTPUT_DIR, "images.txt"), "w") as f_img:
    f_cam.write("# CAMERA_ID, MODEL, WIDTH, HEIGHT, PARAMS[]\n")
    f_img.write("# IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID, NAME\n")
    for i, p in enumerate(poses):
        f_cam.write(f"{i + 1} PINHOLE {W} {H} {fx} {fy} {cx} {cy}\n")
        f_img.write(f"{i + 1} {p[0]} {p[1]} {p[2]} {p[3]} {p[4]} {p[5]} {p[6]} {i + 1} {i:03d}.png\n\n")

# 3. COLMAP BINARY for the trainer (sparse/0): cameras.bin + images.bin
with open(os.path.join(SPARSE_DIR, "cameras.bin"), "wb") as f:
    f.write(struct.pack("<Q", NUM_CAMERAS))
    for i in range(NUM_CAMERAS):
        f.write(struct.pack("<iiQQdddd", i + 1, 1, W, H, fx, fy, cx, cy))   # model 1 = PINHOLE
with open(os.path.join(SPARSE_DIR, "images.bin"), "wb") as f:
    f.write(struct.pack("<Q", NUM_CAMERAS))
    for i, p in enumerate(poses):
        f.write(struct.pack("<i", i + 1))
        f.write(struct.pack("<dddd", *p[0:4]))
        f.write(struct.pack("<ddd", *p[4:7]))
        f.write(struct.pack("<i", i + 1))
        f.write(COLMAP_NAME_FMT.format(cam=i + 1).encode() + b"\x00")
        f.write(struct.pack("<Q", 0))


# 3D points per frame (on the real mesh; replaces COLMAP triangulation)
rng = np.random.default_rng(0)


def material_color(obj, slot):
    try:
        mat = obj.material_slots[slot].material
        if mat and mat.use_nodes:
            for n in mat.node_tree.nodes:
                if n.type == 'BSDF_PRINCIPLED':
                    c = n.inputs['Base Color'].default_value
                    return np.array([c[0], c[1], c[2]], dtype=np.float32) * 255.0
        if mat:
            c = mat.diffuse_color
            return np.array([c[0], c[1], c[2]], dtype=np.float32) * 255.0
    except Exception:
        pass
    return np.array([180, 180, 180], dtype=np.float32)


def get_mesh_data(obj, dg):
    ev = obj.evaluated_get(dg)
    me = ev.to_mesh()
    me.calc_loop_triangles()
    nv, nt = len(me.vertices), len(me.loop_triangles)
    v = np.empty(nv * 3, dtype=np.float32)
    me.vertices.foreach_get("co", v)
    v = v.reshape(-1, 3)
    tri = np.empty(nt * 3, dtype=np.int32)
    me.loop_triangles.foreach_get("vertices", tri)
    tri = tri.reshape(-1, 3)
    mi = np.empty(nt, dtype=np.int32)
    me.loop_triangles.foreach_get("material_index", mi)
    mw = np.array(ev.matrix_world, dtype=np.float32)
    v_world = (np.c_[v, np.ones(nv, dtype=np.float32)] @ mw.T)[:, :3]
    ev.to_mesh_clear()
    return v_world, tri, mi


mesh_objs = [o for o in scene.objects
             if o.type == 'MESH' and not o.hide_render and o.name not in EXCLUDE_NAMES]
if not mesh_objs:
    raise Exception("No render-visible meshes found (EXCLUDE_NAMES too strict?).")
print("Objects for point cloud:", [o.name for o in mesh_objs])

plan = {}


def export_points(frame_idx, first):
    dg = bpy.context.evaluated_depsgraph_get()
    if first:
        areas = {}
        for o in mesh_objs:
            v, tri, mi = get_mesh_data(o, dg)
            a = 0.5 * np.linalg.norm(np.cross(v[tri[:, 1]] - v[tri[:, 0]], v[tri[:, 2]] - v[tri[:, 0]]), axis=1)
            areas[o.name] = (a, tri, mi)
        total = sum(a.sum() for a, _, _ in areas.values())
        for o in mesh_objs:
            a, tri, mi = areas[o.name]
            n = max(1, int(POINTS_PER_FRAME * a.sum() / total))
            sel = rng.choice(len(a), size=n, p=a / a.sum())
            u, w = rng.random(n), rng.random(n)
            fl = u + w > 1
            u[fl], w[fl] = 1 - u[fl], 1 - w[fl]
            bary = np.stack([1 - u - w, u, w], axis=1).astype(np.float32)
            cols = np.stack([material_color(o, int(mi[t])) for t in sel])
            plan[o.name] = (sel, bary, cols, len(tri))
    P, C = [], []
    for o in mesh_objs:
        sel, bary, cols, ntri = plan[o.name]
        v, tri, _ = get_mesh_data(o, dg)
        if len(tri) != ntri:
            print(f"WARNING: topology of {o.name} changes at frame {frame_idx}")
            sel = np.clip(sel, 0, len(tri) - 1)
        tv = tri[sel]
        P.append(v[tv[:, 0]] * bary[:, :1] + v[tv[:, 1]] * bary[:, 1:2] + v[tv[:, 2]] * bary[:, 2:3])
        C.append(cols)
    P = np.concatenate(P).astype(np.float32)
    C = np.concatenate(C).astype(np.float32)
    np.save(os.path.join(POINTS_DIR, f"points3d_frame{frame_idx:06d}.npy"), P)
    np.save(os.path.join(POINTS_DIR, f"colors_frame{frame_idx:06d}.npy"), C)
    return P, C


def link_or_copy(src, dst):
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.lexists(dst):
        os.remove(dst)
    try:
        os.link(src, dst)
    except Exception:
        shutil.copy2(src, dst)


# 4. Loop through all frames: export points + render
first_P = first_C = None
for frame in range(START_FRAME, END_FRAME + 1):
    scene.frame_set(frame)
    idx = frame - START_FRAME
    P, C = export_points(idx, first=(frame == START_FRAME))
    if frame == START_FRAME:
        first_P, first_C = P, C
        R = float(np.linalg.norm(P, axis=1).max())
        px = fx * R / DOME_RADIUS
        print(f"Object radius ~{R:.2f} -> about {px:.0f}px of the {min(W, H) / 2:.0f}px half frame height")
        if px < 0.25 * min(W, H) / 2:
            print("WARNING: the object becomes very small in the frame. Decrease DOME_RADIUS "
                  f"(target value ~{R * fx / (0.7 * min(W, H) / 2):.0f}) or increase the lens.")
    print(f"frame {frame}: {len(P)} points")

    frame_dir = os.path.join(OUTPUT_DIR, f"frame_{frame:03d}")
    os.makedirs(frame_dir, exist_ok=True)
    if not RENDER:
        continue
    for i, cam in enumerate(cameras):
        scene.camera = cam
        render.filepath = os.path.join(frame_dir, f"{i:03d}.png")
        bpy.ops.render.render(write_still=True)
        link_or_copy(render.filepath,
                     os.path.join(IMG_DIR, TRAINER_IMG_FMT.format(cam=i + 1, frame=idx)))

# 5. points3D.bin from frame 1 (only for scene normalization; empty tracks)
sel = rng.choice(len(first_P), size=min(INIT_POINTS_BIN, len(first_P)), replace=False)
with open(os.path.join(SPARSE_DIR, "points3D.bin"), "wb") as f:
    f.write(struct.pack("<Q", len(sel)))
    for k, j in enumerate(sel):
        r, g, b = np.clip(first_C[j], 0, 255).astype(np.uint8)
        f.write(struct.pack("<Q", k + 1))
        f.write(struct.pack("<ddd", *first_P[j].astype(np.float64)))
        f.write(struct.pack("<BBB", int(r), int(g), int(b)))
        f.write(struct.pack("<d", 0.0))
        f.write(struct.pack("<Q", 0))

print(f"Done! files: {OUTPUT_DIR}")